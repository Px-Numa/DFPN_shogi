[![Build Status](https://travis-ci.org/sugyan/shogi.svg?branch=master)](https://travis-ci.org/sugyan/shogi)

# shogi

Shogi (将棋) program


## License

[Shogi images by muchonovski](http://mucho.girly.jp/bona/) below `util/image/data` directory are under a [Creative Commons 表示-非営利 2.1 日本 License](http://creativecommons.org/licenses/by-nc/2.1/jp/).
